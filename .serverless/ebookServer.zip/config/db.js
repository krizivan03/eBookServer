module.exports =  {
    user: 'dreamTeam412',
    password: 'qweasdzxc123',
    host: 'ebookinstance.ckt6nm6ikwi1.us-east-1.rds.amazonaws.com',
    database: 'ebook-test'
  }